import { Employee } from "@/types/employee";

export const mockEmployees: Employee[] = [

{
id:"1",
documento:"1020304050",
nombre:"Juan Felipe Alzate",
cargo:"Soporte TI",
dependencia:"Tecnología",
estado:"ACTIVO"
},

{
id:"2",
documento:"1000000001",
nombre:"Angie Cárdenas",
cargo:"Administrativa",
dependencia:"Administración",
estado:"ACTIVO"
},

{
id:"3",
documento:"1000000002",
nombre:"Carlos Pérez",
cargo:"Docente",
dependencia:"Primaria",
estado:"VACACIONES"
},

{
id:"4",
documento:"1000000003",
nombre:"Laura Gómez",
cargo:"Servicios Generales",
dependencia:"Mantenimiento",
estado:"LICENCIA"
},

{
id:"5",
documento:"1000000004",
nombre:"Pedro Rodríguez",
cargo:"Coordinador",
dependencia:"Académica",
estado:"INACTIVO"
}

];