import { MongoClient } from "mongodb";

const uri = process.env.MONGODB_URI!;

if (!uri) {
    throw new Error("Falta la variable MONGODB_URI");
}

let client: MongoClient;
let clientPromise: Promise<MongoClient>;

declare global {
    var _mongoClientPromise: Promise<MongoClient> | undefined;
}

if (process.env.NODE_ENV === "development") {

    if (!global._mongoClientPromise) {

        client = new MongoClient(uri);

        global._mongoClientPromise = client.connect();

    }

    clientPromise = global._mongoClientPromise;

} else {

    client = new MongoClient(uri);

    clientPromise = client.connect();

}

export default clientPromise;