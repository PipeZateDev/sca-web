import clientPromise from "@/lib/mongodb";

export async function employeeCollection() {

    const client = await clientPromise;

    const db = client.db(process.env.MONGODB_DB);

    return db.collection("empleados");

}