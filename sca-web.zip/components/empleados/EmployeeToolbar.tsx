import { Search, Plus, Upload } from "lucide-react";

export default function EmployeeToolbar() {

    return (

        <div className="flex justify-between items-center mb-6">

            <div className="relative w-96">

                <Search
                    size={18}
                    className="absolute left-3 top-3 text-gray-400"
                />

                <input

                    placeholder="Buscar empleado..."

                    className="w-full border rounded-xl pl-10 pr-4 py-3"

                />

            </div>

            <div className="flex gap-3">

                <button className="bg-white border rounded-xl px-5 py-3 flex items-center gap-2">

                    <Upload size={18} />

                    Importar

                </button>

                <button className="bg-[#0B4F8A] text-white rounded-xl px-5 py-3 flex items-center gap-2">

                    <Plus size={18} />

                    Nuevo

                </button>

            </div>

        </div>

    );

}