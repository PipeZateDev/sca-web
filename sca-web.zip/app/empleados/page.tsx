import MainLayout from "@/components/layout/MainLayout";

import PageTitle from "@/components/ui/PageTitle";

import EmployeeToolbar from "@/components/empleados/EmployeeToolbar";

import EmployeeTable from "@/components/empleados/EmployeeTable";

export default function EmployeesPage(){

return(

<MainLayout>

<PageTitle

title="Empleados"

subtitle="Administración de empleados del colegio"

/>

<EmployeeToolbar/>

<EmployeeTable/>

</MainLayout>

);

}